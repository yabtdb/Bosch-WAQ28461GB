from flask import Flask, render_template

app = Flask(__name__)

def loe_failist(failinimi):     # Defineerib funktsiooni, mis loeb andmeid antud failist
    joogid = []          # Loob tühja järjendi
    with open(failinimi) as fail:     # Avab faili ning suleb selle automaatselt peale sisu lugemist
        for rida in fail:           # Käib läbi iga rea failis
            osad = rida.strip().split(',')      # Eemaldab reast tühikud ja jagab selle komade kaupa osadeks
            joogid.append(osad)      # Lisab jaotatud osad järjendisse
    return joogid        # Tagastab järjendi

@app.route('/')

def avaleht():           # Definerrib funktsiooni
    joogid = loe_failist('joogid.txt')   # Kutsub esile funktsiooni, et lugeda andmeid failist 'joogid.txt'
    return render_template('avaleht.html', joogid = joogid)    # Edastab joogid 'avaleht.html' lehele

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000) # Lisasin selle hosti ja pordi, sest veebileht ei laadinud ära